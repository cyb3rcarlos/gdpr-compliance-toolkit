// DOM needs to load in for the rest to work
document.addEventListener("DOMContentLoaded", function () {
  // --- AI Chatbot Form ---
  const chatForm = document.getElementById("chat-form");
  const userInput = document.getElementById("user-input");
  const chatBox = document.getElementById("chat-box");

  if (chatForm) {
    chatForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      const message = userInput.value.trim();
      if (!message) return;

      // Display user's message
      const userMessageElem = document.createElement("div");
      userMessageElem.className = "user-message";
      userMessageElem.textContent = "You: " + message;
      chatBox.appendChild(userMessageElem);

      userInput.value = "";

      try {
        const response = await fetch("/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ message }),
        });

        const data = await response.json();

        const aiMessageElem = document.createElement("div");
        aiMessageElem.className = "ai-message";
        aiMessageElem.textContent = "AI: " + data.reply;
        chatBox.appendChild(aiMessageElem);
        chatBox.scrollTop = chatBox.scrollHeight;
      } catch (error) {
        console.error("Error contacting AI:", error);
        const errorElem = document.createElement("div");
        errorElem.className = "error-message";
        errorElem.textContent = "Error contacting AI.";
        chatBox.appendChild(errorElem);
      }
    });
  }

  // --- File Upload Preview ---
  const fileInput = document.getElementById("file-upload");
  const fileListDisplay = document.getElementById("file-list");

  if (fileInput && fileListDisplay) {
    fileInput.addEventListener("change", () => {
      const files = fileInput.files;
      fileListDisplay.innerHTML = "";

      for (let i = 0; i < files.length; i++) {
        const fileItem = document.createElement("li");
        fileItem.textContent = files[i].name;
        fileListDisplay.appendChild(fileItem);
      }
    });
  }

  // --- Contact Form Submission ---
  const contactForm = document.getElementById("contactForm");
  const responseMessage = document.getElementById("responseMessage");

  if (contactForm) {
    contactForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const name = contactForm.name.value.trim();
      const email = contactForm.email.value.trim();
      const message = contactForm.message.value.trim();

      responseMessage.textContent = "Sending...";
      responseMessage.style.color = "black";

      try {
        const res = await fetch("/contact", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name, email, message }),
        });

        const data = await res.json();

        if (res.ok) {
          responseMessage.textContent = "Message sent successfully!";
          responseMessage.style.color = "green";
          contactForm.reset();
        } else {
          responseMessage.textContent = data.error || "Something went wrong.";
          responseMessage.style.color = "red";
        }
      } catch (err) {
        responseMessage.textContent = "Failed to send message.";
        responseMessage.style.color = "red";
      }
    });
  }
});
