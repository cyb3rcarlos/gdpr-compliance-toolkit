// Load enviroment variables from .env
require('dotenv').config();

//Console Log for SMTP Gmal to see what's going wrong
console.log('GMAIL_USER:', process.env.GMAIL_USER);
console.log('GMAIL_PASS:', process.env.GMAIL_PASS ? '[HIDDEN]' : 'NOT SET');


// Import all my dependencies
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const multer = require('multer');
const { OpenAI } = require('openai');

// Starts Express app
const app = express();
const port = process.env.PORT || 3000;

// Setup OpenAI API client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY, // Using the key from .env
});

// Middleware
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the "public" folder
app.use(express.static(path.join(__dirname, 'public')));

// Serve uploaded files from the "uploads" folder
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Ensure "uploads" directory exists
const fs = require('fs');
const uploadsPath = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsPath)) {
  fs.mkdirSync(uploadsPath);
}

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Route: Home page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route: Handle chat requests
app.post('/chat', async (req, res) => {
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'No message provided' });
  }

  try {
    // GPT-3.5 turbo is the best and cheapest model for this project
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // Cheapest model (can switch to GPT-4 if you want, but it costs more)
      messages: [{ role: 'user', content: message }],
    });

    const reply = completion.choices[0].message.content.trim();
    res.json({ reply });
  } catch (error) {
    console.error('OpenAI API error:', error.response?.data || error.message);
    res.status(500).json({ error: 'Failed to get a response from OpenAI' });
  }
});

// Route: Handle file uploads
app.post('/upload', upload.array('files'), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ uploaded: [] });
  }

  const uploadedFiles = req.files.map(file => file.filename);
  res.json({ uploaded: uploadedFiles });
});
// Import nodemailer for sending emails
const nodemailer = require('nodemailer');

// Create a transporter using Gmail's SMTP server
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS,
  },
});

// Route: Handle contact form submission
app.post('/send-contact', async (req, res) => {
  const { name, email, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const mailOptions = {
    from: email,
    to: process.env.GMAIL_USER,
    subject: `Contact Form Submission from ${name}`,
    text: `You received a message from ${name} (${email}):\n\n${message}`,
  };

  try {
    await transporter.sendMail(mailOptions);
    res.status(200).json({ success: 'Message sent successfully' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`✅ Server running at http://localhost:${port}`);
});
